function wufeng(xuanzeqi,sudu){
	var myul = $(xuanzeqi) //得到ul
	
	var mytimer = 0;
	var nowleft = 0;
	var zhefandian = 0;
	//each类似for，计算折返点
	myul.children("li").each(
		function(){
			zhefandian = zhefandian + $(this).outerWidth(true);
		}
	);

	//复制一倍结点
	myul.html(myul.html()+myul.html());

	dongdong();	//调用dongdong函数

	//这是dongdong函数
	function dongdong(){
		//设表先关
		window.clearInterval(mytimer);
		mytimer = window.setInterval(
			function(){
				//判终停表
				if(nowleft == -zhefandian){
					nowleft = 0;
				}else{
					nowleft = nowleft - 1;
				}
				myul.css("left",nowleft);
			}
		,sudu);
	}

	//为鼠标进入，添加事件监听
	myul.mouseenter(
		function(){
			//鼠标进入，停表
			window.clearInterval(mytimer);
		}
	);

	myul.mouseleave(dongdong);
}