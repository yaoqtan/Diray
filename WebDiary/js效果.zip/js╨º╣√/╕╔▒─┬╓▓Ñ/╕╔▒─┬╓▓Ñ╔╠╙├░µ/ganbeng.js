﻿function ganbenglunbo(shijian){
	 	
	var mytulis = document.getElementById("tuul").getElementsByTagName("li"); 
	var mydianlis = document.getElementById("dianul").getElementsByTagName("li");
	var myas = document.getElementById("tuul").getElementsByTagName("a");
	var myrightbut = document.getElementById("right_but");
	var myleftbut = document.getElementById("left_but");
	var mybiaoti = document.getElementById("biaoti");
	var myganbeng = document.getElementById("ganbeng");
	var nowimg = 0;	
	var mytimer = 0;

	//右按钮
	myrightbut.onclick = youanniushijian;

	//定时器
	mytimer = window.setInterval(youanniushijian,shijian);
	myganbeng.onmouseover = function(){
		window.clearInterval(mytimer);
	}
	myganbeng.onmouseout = function(){
		mytimer = window.setInterval(youanniushijian,shijian);
	}

	//右按钮的函数
	function youanniushijian(){
		if(nowimg < mytulis.length - 1){
			nowimg ++;
		}else{
			nowimg = 0;
		}
		huantu();
		shezhixiaoyuandian();
		shezhibiaoti();
	}

	//左按钮函数
	myleftbut.onclick = function(){
		if(nowimg > 0){
			nowimg --;
		}else{
			nowimg = mytulis.length - 1;
		}
		huantu();
		shezhixiaoyuandian();
		shezhibiaoti();
	}

	//小圆点事件
	for(var i = 0 ; i <= mydianlis.length - 1 ; i++){
		mydianlis[i].index = i;
		mydianlis[i].onmouseover = function(){
			nowimg = this.index;
			huantu();
			shezhixiaoyuandian();
			shezhibiaoti();
		}
	}

	//3个函数
	function huantu(){
		for(var i = 0 ; i <= mytulis.length - 1; i++){
			mytulis[i].className = "";
		}
		mytulis[nowimg].className = "cur";
	}

	function shezhixiaoyuandian(){
		for(var i = 0 ; i <= mydianlis.length - 1; i ++){
			mydianlis[i].className = "";
		}
		mydianlis[nowimg].className = "cur";
	}

	function shezhibiaoti(){
		mybiaoti.innerHTML = myas[nowimg].title;
	}
}