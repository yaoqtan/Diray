$("html").css("fontSize",$(window).width()/160*7+"px");
$(window).resize(function(){$("html").css("fontSize",$(window).width()/160*7+"px");});  

window.onload = function function_name () {
    $(".loading").fadeOut("400");
    $(".touxiang").attr("style","-webkit-animation: bounceinT 1s linear .5s both;animation: bounceinT 1s linear .5s; both;opacity: 1;");
    $(".jianli,.xingming").attr("style","-webkit-animation: fadeinR 1s linear .5s both;animation: fadeinR 1s linear .5s; both;opacity: 1;");
    $(".line").attr("style","-webkit-animation:bounceinL .5s ease 1s both;animation:bounceinL .5s ease 1s both;opacity: 1;");
    $(".zhiye").attr("style","-webkit-animation: bounceinL 1s linear .5s both;animation: bounceinL 1s linear .5s; both;opacity: 1;");
    var sHeight = $(window).height();
    var sWidth = $(window).width();
    $('#homeSwipe').css({width: sWidth + 'px', height: sHeight + 'px'});
    $('.swiper-slide').css({width: sWidth + 'px', height: sHeight + 'px'});

    var zuoyou = true; //手势状态

    var homeSwiper = new Swiper('#homeSwipe', {
        pagination: '',
        mode: 'vertical',
        onSlideChangeEnd:function(swiper){  
            $(".fangkuai,.line_s,.shijianzhou_txt,.shijianzhou2_txt,.p3_con,.meirong,.fu_title,.two1,.two2,,.two3,.two4,.two5,.two6,.two7,.p5_con1,.p5_con2,.p5_con3,.p5_con4,.bwzq,.zqyx,.p9_con,.thank,.touxiang,.jianli,.xingming,.zhiye,.line").attr("style","");
            if (homeSwiper.activeIndex==0) {
                $(".touxiang").attr("style","-webkit-animation: bounceinT 1s linear .5s both;animation: bounceinT 1s linear .5s; both;opacity: 1;");
                $(".jianli,.xingming").attr("style","-webkit-animation: fadeinR 1s linear .5s both;animation: fadeinR 1s linear .5s; both;opacity: 1;");
                $(".zhiye").attr("style","-webkit-animation: bounceinL 1s linear .5s both;animation: bounceinL 1s linear .5s; both;opacity: 1;");
                $(".line").attr("style","-webkit-animation:bounceinL .5s ease 1s both;animation:bounceinL .5s ease 1s both;opacity: 1;");
            }
            if(homeSwiper.activeIndex==1){   
                $(".fangkuai:eq(0)").attr("style","-webkit-animation:fadein .5s ease .5s both;animation:fadein .5s ease .5s both;opacity: 1;");
                $(".line_s:eq(0)").attr("style","-webkit-animation:fadein .5s ease 1s both;animation:fadein .5s ease 1s both;opacity: 1;"); 
                $(".shijianzhou_txt:eq(0)").attr("style","-webkit-animation:fadeinR .5s ease 1.5s both;animation:fadeinR .5s ease 1.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(0)").attr("style","-webkit-animation:fadeinR .5s ease 2s both;animation:fadeinR .5s ease 2s both;opacity: 1;"); 

                $(".fangkuai:eq(1)").attr("style","-webkit-animation:fadein .5s ease 2.5s both;animation:fadein .5s ease 2.5s both;opacity: 1;");
                $(".line_s:eq(1)").attr("style","-webkit-animation:fadein .5s ease 3s both;animation:fadein .5s ease 3s both;opacity: 1;"); 
                $(".shijianzhou_txt:eq(1)").attr("style","-webkit-animation:fadeinR .5s ease 3.5s both;animation:fadeinR .5s ease 3.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(1)").attr("style","-webkit-animation:fadeinR .5s ease 4s both;animation:fadeinR .5s ease 4s both;opacity: 1;"); 

                $(".fangkuai:eq(1)").attr("style","-webkit-animation:fadein .5s ease 2.5s both;animation:fadein .5s ease 2.5s both;opacity: 1;");
                $(".line_s:eq(1)").attr("style","-webkit-animation:fadein .5s ease 3s both;animation:fadein .5s ease 3s both;opacity: 1;"); 
                $(".shijianzhou_txt:eq(1)").attr("style","-webkit-animation:fadeinR .5s ease 3.5s both;animation:fadeinR .5s ease 3.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(1)").attr("style","-webkit-animation:fadeinR .5s ease 4s both;animation:fadeinR .5s ease 4s both;opacity: 1;"); 

                $(".fangkuai:eq(2)").attr("style","-webkit-animation:fadein .5s ease 4.5s both;animation:fadein .5s ease 4.5s both;opacity: 1;");
                $(".line_s:eq(2)").attr("style","-webkit-animation:fadein .5s ease 5s both;animation:fadein .5s ease 5s both;opacity: 1;"); 
                $(".shijianzhou_txt:eq(2)").attr("style","-webkit-animation:fadeinR .5s ease 5.5s both;animation:fadeinR .5s ease 5.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(2)").attr("style","-webkit-animation:fadeinR .5s ease 6s both;animation:fadeinR .5s ease 6s both;opacity: 1;"); 

                $(".fangkuai:eq(3)").attr("style","-webkit-animation:fadein .5s ease 6.5s both;animation:fadein .5s ease 6.5s both;opacity: 1;");
                $(".line_s:eq(3)").attr("style","-webkit-animation:fadein .5s ease 7s both;animation:fadein .5s ease 7s both;opacity: 1;"); 
                $(".shijianzhou_txt:eq(3)").attr("style","-webkit-animation:fadeinR .5s ease 7.5s both;animation:fadeinR .5s ease 7.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(3)").attr("style","-webkit-animation:fadeinR .5s ease 8s both;animation:fadeinR .5s ease 8s both;opacity: 1;"); 

                $(".fangkuai:eq(4)").attr("style","-webkit-animation:fadein .5s ease 8.5s both;animation:fadein .5s ease 8.5s both;opacity: 1;");
                $(".shijianzhou_txt:eq(4)").attr("style","-webkit-animation:fadeinR .5s ease 9.5s both;animation:fadeinR .5s ease 9.5s both;opacity: 1;"); 
                $(".shijianzhou2_txt:eq(4)").attr("style","-webkit-animation:fadeinR .5s ease 10s both;animation:fadeinR .5s ease 10s both;opacity: 1;"); 
            }
            if(homeSwiper.activeIndex==2){  
                
                $(".p3_con").attr("style","-webkit-animation:bounceinT .5s ease .5s both;animation:bounceinT .5s ease .5s both;opacity: 1;");
            }   
            if(homeSwiper.activeIndex==3){  
                $(".meirong").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
                $(".fu_title").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
                $(".two1").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");

                if (true) {
                    setTimeout(function(){
                        $(".zuoyou").fadeOut("slow");
                        zuoyou = false;
                    }, 2500);
                };
            }
            if(homeSwiper.activeIndex==4){
               $(".two2").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
               $(".p5_con1").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
            }
            if(homeSwiper.activeIndex==5){
               $(".two3").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
               $(".p5_con2").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
            }
            if(homeSwiper.activeIndex==6){
               $(".two4").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
               $(".p5_con3").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
            }
            if(homeSwiper.activeIndex==7){
               $(".two5").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
               $(".p5_con4").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
            }
            if(homeSwiper.activeIndex==8){
               $(".bwzq").attr("style","-webkit-animation:fadeinB .5s ease .5s both;animation:fadeinB .5s ease .5s both;opacity: 1;");
               $(".two6").attr("style","-webkit-animation:fadeinB .5s ease 1s both;animation:fadeinB .5s ease 1s both;opacity: 1;");
               $(".zqyx").attr("style","-webkit-animation:fadeinB .5s ease 1.5s both;animation:fadeinB .5s ease 1.5s both;opacity: 1;");
               $(".two7").attr("style","-webkit-animation:fadeinB .5s ease 2s both;animation:fadeinB .5s ease 2s both;opacity: 1;");
               $(".bottom").show();
            }
            if(homeSwiper.activeIndex==9){
               $(".p9_con").attr("style","-webkit-animation:rotateinLT .5s ease .5s both;animation:rotateinLT .5s ease .5s both;opacity: 1;");
               $(".thank").attr("style","-webkit-animation:fadeinB 1.5s ease 1s both;animation:fadeinB 1.5s ease 1s both;opacity: 1;");
               $(".bottom").hide();
            }
        }
    });
    var swiperNested1 = new Swiper('.swiper-nested-1',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
     $('.arrow-left1').on('click', function(e){
        e.preventDefault();
        swiperNested1.swipePrev();
    });
      $('.arrow-right1').on('click', function(e){
        e.preventDefault();
        swiperNested1.swipeNext();
    });

    var swiperNested2 = new Swiper('.swiper-nested-2',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left2').on('click', function(e){
        e.preventDefault();
        swiperNested2.swipePrev();
    });
      $('.arrow-right2').on('click', function(e){
        e.preventDefault();
        swiperNested2.swipeNext();
    });

    var swiperNested3 = new Swiper('.swiper-nested-3',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left3').on('click', function(e){
        e.preventDefault();
        swiperNested3.swipePrev();
    });
      $('.arrow-right3').on('click', function(e){
        e.preventDefault();
        swiperNested3.swipeNext();
    });
    var swiperNested4 = new Swiper('.swiper-nested-4',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left4').on('click', function(e){
        e.preventDefault();
        swiperNested4.swipePrev();
    });
      $('.arrow-right4').on('click', function(e){
        e.preventDefault();
        swiperNested4.swipeNext();
    });
    var swiperNested5 = new Swiper('.swiper-nested-5',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left5').on('click', function(e){
        e.preventDefault();
        swiperNested5.swipePrev();
    });
      $('.arrow-right5').on('click', function(e){
        e.preventDefault();
        swiperNested5.swipeNext();
    });
    var swiperNested6 = new Swiper('.swiper-nested-6',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left6').on('click', function(e){
        e.preventDefault();
        swiperNested6.swipePrev();
    });
      $('.arrow-right6').on('click', function(e){
        e.preventDefault();
        swiperNested6.swipeNext();
    });
    var swiperNested7 = new Swiper('.swiper-nested-7',{
        mode: 'horizontal',
        pagination: '',
        autoplay:'3000'
    });
    $('.arrow-left7').on('click', function(e){
        e.preventDefault();
        swiperNested7.swipePrev();
    });
      $('.arrow-right7').on('click', function(e){
        e.preventDefault();
        swiperNested7.swipeNext();
    });
}